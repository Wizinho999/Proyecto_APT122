export const supabaseConfig = {
  url: "https://pocvvpwbplpqqqmykcwc.supabase.co",
  anonKey:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBvY3Z2cHdicGxwcXFxbXlrY3djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAwNTA4MjIsImV4cCI6MjA3NTYyNjgyMn0.z6vnkNAV69QEjShae9lQJhc-SvZONsnFYoYe0Gg5Zn0",
}
